<?php
//$con=mysqli_connect("localhost","root","","loginsystem");

$cleardb_url = parse_url(getenv("CLEARDB_DATABASE_URL"));
$cleardb_server = $cleardb_url["host"];
$cleardb_username = $cleardb_url["user"];
$cleardb_password = $cleardb_url["pass"];
$cleardb_db = substr($cleardb_url["path"],1);
$active_group = 'default';
$query_builder = TRUE;

$con = mysqli_connect($cleardb_server, $cleardb_username, $cleardb_password, $cleardb_db);
if(isset($_POST['login_submit'])){
	$username=$_POST['username'];
	$password=$_POST['password'];
	$query="select * from logintb where username='$username' and password='$password'";
	$result=mysqli_query($con,$query);
	
	$count = mysqli_num_rows($result);
	
	if($count == 1)
	{
		header("Location:admin-panel.php");
	
}
	else
    {
        echo "<script>alert('Error Login')</script>";
        echo "<script>window.open('index.php','_self')</script>";
    }
    }
if(isset($_POST['pat_submit']))
{
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $contact=$_POST['contact'];
    $docapp=$_POST['docapp'];
	
	$flag =0;
	
	//validation
	if($flag==0){
		
		if(empty($fname)){
		echo "<script>alert('First name is a required field')</script>";
			echo "<script>window.open('admin-panel.php','_self')</script>";
			$flag =1;
	}else{
		if (!preg_match("/^[a-zA-Z ]*$/",$fname)) {    
			echo "<script>alert('Only alphabets and white space are allowed in first name')</script>";
			echo "<script>window.open('admin-panel.php','_self')</script>";
				$flag=1;
            }  
	}
		
	if(empty($lname)){
		echo "<script>alert('Last name is a required field')</script>";
		echo "<script>window.open('admin-panel.php','_self')</script>";
			$flag=1;
	}else{
		if (!preg_match("/^[a-zA-Z ]*$/",$lname)) {    
			echo "<script>alert('Only alphabets and white space are allowed in last name')</script>";
			echo "<script>window.open('admin-panel.php','_self')</script>";
				$flag=1;
            }  
	}
	
	if(empty($email)){
		echo "<script>alert('Email is a required field')</script>";
		echo "<script>window.open('admin-panel.php','_self')</script>";
			$flag=1;
	}else{
		if (!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^",$email)) {    
			echo "<script>alert('Email is not valid')</script>";
			echo "<script>window.open('admin-panel.php','_self')</script>";
				$flag=1;
            }  
	}
		
	if(empty($contact)){
		echo "<script>alert('Member ID is a required field')</script>";
		echo "<script>window.open('admin-panel.php','_self')</script>";
			$flag=1;
	}else{
		if (!preg_match("/^[0-9]*$/",$contact)) {    
			echo "<script>alert('Member ID must be numeric')</script>";
			echo "<script>window.open('admin-panel.php','_self')</script>";
				$flag=1;
            }  
	}
			
}
	
	
	
	if($flag==0){
    $query="insert into doctorapp(fname,lname,email,contact,docapp)values('$fname','$lname','$email','$contact','$docapp')";
     $result=mysqli_query($con,$query);
    if($result)
    {
      echo "<script>alert('Member added.')</script>";
        echo "<script>window.open('admin-panel.php','_self')</script>";
    }
}
} 
if(isset($_POST['tra_submit']))
{
	$Trainer_id=$_POST['Trainer_id'];
	$Name=$_POST['Name'];
	$phone=$_POST['phone'];
	
	
	$flag =0;
	
	//validation
	if($flag==0){
		
		if(empty($Trainer_id)){
		echo "<script>alert('Trainer ID is a required field')</script>";
			echo "<script>window.open('trainer.php','_self')</script>";
			$flag =1;
	}else{
		if (!preg_match("/^[0-9]*$/",$Trainer_id)) {    
			echo "<script>alert('Trainer ID must be numeric')</script>";
			echo "<script>window.open('trainer.php','_self')</script>";
				$flag=1;
            }  
	}
		
	if(empty($Name)){
		echo "<script>alert('Name is a required field')</script>";
		echo "<script>window.open('trainer.php','_self')</script>";
			$flag=1;
	}else{
		if (!preg_match("/^[a-zA-Z ]*$/",$Name)) {    
			echo "<script>alert('Only alphabets and white space are allowed in Name field')</script>";
			echo "<script>window.open('trainer.php','_self')</script>";
				$flag=1;
            }  
	}
	

		
	if(empty($phone)){
		echo "<script>alert('Phone is a required field')</script>";
		echo "<script>window.open('trainer.php','_self')</script>";
			$flag=1;
	}else{
		if (!preg_match("/^[0-9]*$/",$contact)) {    
			echo "<script>alert('Member ID must be numeric')</script>";
			echo "<script>window.open('admin-panel.php','_self')</script>";
				$flag=1;
            }
		if (strlen ($phone) != 10) {  
			echo "<script>alert('Mobile no must contain 10 digits.')</script>";
			echo "<script>window.open('trainer.php','_self')</script>";
			$flag=1;
    
            } 
	}
			
}
	
	
	
	if($flag==0){
		$query="insert into Trainer(Trainer_id,Name,phone)values('$Trainer_id','$Name','$phone')";
	 $result=mysqli_query($con,$query);
		if($result)
		{
		  echo "<script>alert('Trainer added.')</script>";
			echo "<script>window.open('trainer.php','_self')</script>";
		}
	}
	
} 

if(isset($_POST['pay_submit']))
{
	$Payment_id=$_POST['Payment_id'];
	$Amount=$_POST['Amount'];
	$customer_id=$_POST['customer_id'];
	$payment_type=$_POST['payment_type'];
	//$customer_name=$_POST['customer_name'];
	
	$flag=0;
		
	if($flag == 0){
		
		if(empty($Payment_id)){
		echo "<script>alert('Payment ID is a required field')</script>";
		echo "<script>window.open('payment.php','_self')</script>";
			$flag=1;
	}else{
		if (!preg_match("/^[0-9]*$/",$Payment_id)) {    
			echo "<script>alert('Payment ID must be numeric')</script>";
			echo "<script>window.open('payment.php','_self')</script>";
				$flag=1;
            }  
	}
		
	if(empty($Amount)){
		echo "<script>alert('Amount is a required field')</script>";
		echo "<script>window.open('payment.php','_self')</script>";
			$flag=1;
	}else{
		if (!preg_match("/^[0-9]*$/",$Amount)) {    
			echo "<script>alert('Amount must be numeric')</script>";
			echo "<script>window.open('payment.php','_self')</script>";
				$flag=1;
            }  
	}
		
	if(empty($customer_id)){
		echo "<script>alert('Member ID is a required field')</script>";
		echo "<script>window.open('payment.php','_self')</script>";
			$flag=1;
	}else{
		if (!preg_match("/^[0-9]*$/",$customer_id)) {    
			echo "<script>alert('Member must be numeric')</script>";
			echo "<script>window.open('payment.php','_self')</script>";
				$flag=1;
            }  
	}
		
//	if(empty($payment_type)){
//		echo "<script>alert('Payment Type is a required field')</script>";
//		echo "<script>window.open('payment.php','_self')</script>";
//			$flag=1;
//	}else{
//		if (!preg_match("/^[a-zA-Z ]*$/",$payment_type)) {    
//			echo "<script>alert('Only alphabets and white space are allowed in Payment type field')</script>";
//			echo "<script>window.open('payment.php','_self')</script>";
//				$flag=1;
//            }
//		else if($payment_type != 'card' || $payment_type != 'cash' || $payment_type != 'cheque'){
//			echo "<script>alert('Payment type should be card/cash/cheque only')</script>";
//			echo "<script>window.open('payment.php','_self')</script>";
//				$flag=1;
//			
//		}
//	}
		
	}
	
	
	if($flag==0){
	$query="insert into Payment(Payment_id,Amount,customer_id,payment_type)values('$Payment_id','$Amount','$customer_id','$payment_type')";
	 $result=mysqli_query($con,$query);
	if($result)
	{
	  echo "<script>alert('Payment sucessfull.')</script>";
		echo "<script>window.open('payment.php','_self')</script>";
	}
	}
} 

if(isset($_POST['patient_search_submit'])){
	$Member_id=$_POST['search'];
	$flag=0;
	
	if(empty($Member_id)){
		echo "<script>alert('Member ID is a required field')</script>";
		echo "<script>window.open('trainer_details.php','_self')</script>";
			$flag=1;
	}else{
		if (!preg_match("/^[0-9]*$/",$Member_id)) {    
			echo "<script>alert('Member ID must be numeric')</script>";
			echo "<script>window.open('trainer_details.php','_self')</script>";
				$flag=1;
            }  
	}
	
}


 function get_patient_details(){
    global $con;
    $query="select * from doctorapp";
    $result=mysqli_query($con,$query);
    while ($row=mysqli_fetch_array($result)){
         $fname=$row ['fname'];
    $lname=$row['lname'];
    $email=$row['email'];
    $contact=$row['contact'];
    $docapp=$row['docapp'];
      echo "<tr>
          <td>$fname</td>
        <td>$lname</td>
            <td>$email</td>
            <td>$contact</td>
          <td>$docapp</td>
        </tr>";
    }
}
function get_package(){
    global $con;
    $query="select * from Package";
    $result=mysqli_query($con,$query);
    while($row=mysqli_fetch_array($result)){
        $Package_id=$row ['Package_id'];
        $Package_name=$row['Package_name'];
        $Amount=$row['Amount'];
        echo"<tr>
        <td>$Package_id</td>
        <td>$Package_name</td>
        <td>$Amount</td>
            
        </tr>";

    }
}
function get_trainer(){
    global $con;
    $query="select * from Trainer";
    $result=mysqli_query($con,$query);
    while($row=mysqli_fetch_array($result)){
        $Trainer_id=$row ['Trainer_id'];
        $Name=$row['Name'];
        $phone=$row['phone'];
        echo"<tr>
        <td>$Trainer_id</td>
        <td>$Name</td>
        <td>$phone</td>
            
        </tr>";

    }
}
function get_payment(){
    global $con;
    $query="select * from Payment";
    $result=mysqli_query($con,$query);
    while($row=mysqli_fetch_array($result)){
        $Payment_id=$row ['Payment_id'];
        $Amount=$row['Amount'];
        $payment_type=$row['payment_type'];
        $customer_id=$row['customer_id'];
        //$customer_name=$row['customer_name'];
        
        echo"<tr>
        <td>$Payment_id</td>
        <td>$Amount</td>
        <td>$payment_type</td>
        <td>$customer_id</td>
        
            </tr>";
//<td>$customer_name</td>
    }
}


?>



